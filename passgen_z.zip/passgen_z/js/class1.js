alert("Hello World Outside!");
$(document).ready(function() {
alert("Hello World! Inside");
safdsfsfafsafdsafaf
	  Vanilla JavaScript
	  document.getElementById('lucy').style.backgroundColor = "red";

	// Make lucy have a 3px solid red border
	//$('#lucy').css('border', '3px solid red');

	// Make both lucy and ricky yellow
	//$('.ricardo').css('background-color', 'yellow');

	// Make the body of the page yellow
	//$('body').css('background-color', 'yellow');

	// Make all the divs green
	//$('div').css('background-color', 'green');

	// Make all the divs dissapear 
	//$('div').hide();


	// When lucy is clicked change her border to blue
	//$('#lucy').click(function() {
	//	$('#lucy').css('border', '4px solid blue');
	//});

	// When lucy is clicked change the width of ricky
	//$('#lucy').click(function() {
	//	$('#ricky').css('width', '400px');
	//});

	// When lucy is hovered dim to half
	//$('#lucy').hover(function() {
	//	$('#lucy').css('opacity', '.5');
	//});

	// When either lucy or ricky is clicked, change height of lucy
	//$('.ricardo').click(function() {
	//	$('#lucy').css('height', '500px');
	//});

	//When either lucy or ricky is clicked make them go away
	//$('.ricardo').click(function() {
	//	$('.ricardo').hide();
	//});


}); // end of doc ready